package com.yourname.womensafety;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
